## Step 0: Load Libraries ##
library(dma)
library(tibbletime)
library(boot)
library(viridis)
library(cowplot)
library(tseries)
library(moments)
library(plyr)
library(tis)
library(lubridate)
library(shape)
library(xlsx)

## Step 1: Get data  ##
setwd("d:/����/9 INE and China fianncial factor/��д")
Data <- read.xlsx("data2.xlsx",sheetIndex=1)
y<-as.matrix(Data[,2])
x<-as.matrix(cbind(
  IR<-Data$IR,
  ER<-Data$ER,
  TR<-Data$TR,
  SHCI<-Data$SHCI,
  EI<-Data$EI,
  CP<-Data$CP
))

## Step 2: Descriptive summary  ##
descriptives = matrix(NA,length(names(Data)[-1]),8)
rownames(descriptives)=names(Data)[-1]
colnames(descriptives)=c("Mean", "Max.", "Min", "St.Dev.", "Skewness", "Kurtosis", "J.B.", "ADF")
signif.num <- function(x) 
{
  symnum(x, corr = FALSE, na = FALSE, legend = FALSE,
         cutpoints = c(0, 0.01, 0.05, 0.1, 1), 
         symbols = c("***", "**", "*", " "))
}

Basic_descriptives = function(z)
{
  c(round(c( mean(z),max(z),min(z),sd(z),skewness(z),kurtosis(z)),3),
    suppressWarnings(paste(round(jarque.bera.test(z)$statistic,3),signif.num(jarque.bera.test(z)$p.value),sep="")),
    suppressWarnings(paste(round(adf.test(z)$statistic,3),signif.num(adf.test(z)$p.value),sep=""))
  )
}

descriptives[1,] = Basic_descriptives(y)
for (i in 1:length(x[1,]) ){descriptives[(1+i),] = Basic_descriptives(x[,i])}

print(descriptives)

## Step 3: primarily analysis  ##
library(vars)
lags=VARselect(data.z, lag.max = 5, type = "const")
p=lags$selection[[1]]
p
est <- VAR(data.z, p = p, type = "const")
causality(est, cause = "e")
#set the amat and bmat#
amat <- diag(4)   ##set diag=the row numbers of data.z
diag(amat) <- NA
amat[2, 1] <- NA
amat[4, 1] <- NA
## Estimation method direct
svar.a=SVAR(x = var.2c, estmethod = "direct", Amat = amat, Bmat = NULL,
            hessian = TRUE, method="BFGS") 
irf1=irf(svar.a, impulse = "e", response = c("prod", "rw"),  n.ahead=10,boot =
           TRUE, runs = 1000)
plot(irf1,col="navy")



### Step 4:    main regression for INE with the DMA model #####
## Step 4-0:  DMA process for INE��For main procedure�� ##


LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



residuals              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                  = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


      for (LAMBDA in LAMBDA_range)
      {
        for (ALPHA in ALPHA_range)
        {
          print(paste(LAMBDA,ALPHA,sep="_"))
          out.temp <- dma(x[,1:6],y,expand.grid(rep(list(0:1), ncol(x[,1:6]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=0)
          
          rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
          mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
          
          col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
          
          temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:6]))))
          
          prob_IR[,col_index]                 = temp_probs[,1]
          prob_ER[,col_index]                 = temp_probs[,2]
          prob_TR[,col_index]                 = temp_probs[,3]
          prob_SHCI[,col_index]               = temp_probs[,4]
          prob_EI[,col_index]                 = temp_probs[,5]
          prob_CP[,col_index]                 = temp_probs[,6]

          
          
          residuals[,col_index]                  = out.temp$residuals
          alpha[,col_index]                      = out.temp$thetahat.ma[,1]
          theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
          theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
          theta_TR[,col_index]                   = out.temp$thetahat.ma[,4]
          theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,5]
          theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
          theta_CP[,col_index]                   = out.temp$thetahat.ma[,7]
          
        }
      }
      
      MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
      RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
      
      rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
      colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)
      
      
      for (LAMBDA in LAMBDA_range)
      {
        for (ALPHA in ALPHA_range)
        {
          MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
          RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
        }
      }

total=out.temp$pmp
write.csv(total,file = "total.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "knowmodels.csv")

## Step 4-1:  DMA process for INE��MAE�� ##
MAE_matrix=MAE_matrix[1:10,1:10]
optimal_MAE  = which(MAE_matrix == min(MAE_matrix), arr.ind = T)
MAE_INDEX  = which(names(mae) == paste(rownames(MAE_matrix)[optimal_MAE[1]],colnames(MAE_matrix)[optimal_MAE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using MAE =",colnames(MAE_matrix)[optimal_MAE[2]])
paste("Optimal lambda forgetting factor value using MAE =",rownames(MAE_matrix)[optimal_MAE[1]])

result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,MAE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,MAE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,MAE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,MAE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,MAE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,MAE_INDEX]


par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")


result_INE_MAE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_INE_MAE, file="result_INE_MAE.csv")

## Step 4-2:  DMA process for INE��RMSE�� ##
RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])


result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]


par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")
result_INE_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_INE_RMSE, file="result_INE_RMSE.csv")

########################################################################


result_IR<-eval(parse(text= paste("theta","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("theta","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("theta","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("theta","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("theta","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("theta","CP",sep="_") ))[,RMSE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")

result_BRENT_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_BRENT_RMSE, file="result_INE_parameter_rmse.csv")


result_IR<-eval(parse(text= paste("theta","IR",sep="_") ))[,MAE_INDEX]
result_ER<-eval(parse(text= paste("theta","ER",sep="_") ))[,MAE_INDEX]
result_SHCI<-eval(parse(text= paste("theta","SHCI",sep="_") ))[,MAE_INDEX]
result_TR<-eval(parse(text= paste("theta","TR",sep="_") ))[,MAE_INDEX]
result_EI<-eval(parse(text= paste("theta","EI",sep="_") ))[,MAE_INDEX]
result_CP<-eval(parse(text= paste("theta","CP",sep="_") ))[,MAE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")

result_BRENT_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_BRENT_RMSE, file="result_INE_parameter_mae.csv")


## Step 5-1:  DMA process for WTI##

Data <- read.xlsx("data2.xlsx",sheetIndex=2)
y<-as.matrix(Data[,2])
x<-as.matrix(cbind(
  IR<-Data$IR,
  ER<-Data$ER,
  SHCI<-Data$SHCI,
  TR<-Data$TR,
  EI<-Data$EI,
  CP<-Data$CP
))



LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



residuals              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                  = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    print(paste(LAMBDA,ALPHA,sep="_"))
    out.temp <- dma(x[,1:6],y,expand.grid(rep(list(0:1), ncol(x[,1:6]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=40)
    
    rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
    mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
    
    col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
    
    temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:6]))))
    
    prob_IR[,col_index]                 = temp_probs[,1]
    prob_ER[,col_index]                 = temp_probs[,2]
    prob_TR[,col_index]                 = temp_probs[,3]
    prob_SHCI[,col_index]               = temp_probs[,4]
    prob_EI[,col_index]                 = temp_probs[,5]
    prob_CP[,col_index]                 = temp_probs[,6]
    
    
    
    residuals[,col_index]                  = out.temp$residuals
    alpha[,col_index]                      = out.temp$thetahat.ma[,1]
    theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
    theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
    theta_TR[,col_index]                   = out.temp$thetahat.ma[,4]
    theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,5]
    theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
    theta_CP[,col_index]                   = out.temp$thetahat.ma[,7]
    
  }
}

MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))

rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
    RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
  }
}

total=out.temp$pmp
write.csv(total,file = "total1.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "knowmodels1.csv")


## Step 5-1-1:  DMA process��MAE�� ##
MAE_matrix=MAE_matrix[1:10,1:10]
optimal_MAE  = which(MAE_matrix == min(MAE_matrix), arr.ind = T)
MAE_INDEX  = which(names(mae) == paste(rownames(MAE_matrix)[optimal_MAE[1]],colnames(MAE_matrix)[optimal_MAE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using MAE =",colnames(MAE_matrix)[optimal_MAE[2]])
paste("Optimal lambda forgetting factor value using MAE =",rownames(MAE_matrix)[optimal_MAE[1]])

result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,MAE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,MAE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,MAE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,MAE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,MAE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,MAE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")

result_WTI_MAE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_WTI_MAE, file="result_WTI_MAE.csv")



## Step 5-1-2:  DMA process��RMSE�� ##
RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])


result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")


result_WTI_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_WTI_RMSE, file="result_WIT_RMSE.csv")

## Step 5-2:  DMA process for Brent##

Data <- read.xlsx("data2.xlsx",sheetIndex=3)
y<-as.matrix(Data[,2])
x<-as.matrix(cbind(
  IR<-Data$IR,
  ER<-Data$ER,
  SHCI<-Data$SHCI,
  TR<-Data$TR,
  EI<-Data$EI,
  CP<-Data$CP
))



LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



residuals              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                  = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    print(paste(LAMBDA,ALPHA,sep="_"))
    out.temp <- dma(x[,1:6],y,expand.grid(rep(list(0:1), ncol(x[,1:6]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=40)
    
    rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
    mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
    
    col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
    
    temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:6]))))
    
    prob_IR[,col_index]                 = temp_probs[,1]
    prob_ER[,col_index]                 = temp_probs[,2]
    prob_TR[,col_index]                 = temp_probs[,3]
    prob_SHCI[,col_index]               = temp_probs[,4]
    prob_EI[,col_index]                 = temp_probs[,5]
    prob_CP[,col_index]                 = temp_probs[,6]
    
    
    
    residuals[,col_index]                  = out.temp$residuals
    alpha[,col_index]                      = out.temp$thetahat.ma[,1]
    theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
    theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
    theta_TR[,col_index]                   = out.temp$thetahat.ma[,4]
    theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,5]
    theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
    theta_CP[,col_index]                   = out.temp$thetahat.ma[,7] 
    
  }
}

MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))

rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
    RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
  }
}

total=out.temp$pmp
write.csv(total,file = "total_brent.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "knowmodels_brent.csv")


## Step 5-1-1:  DMA process��MAE�� ##
MAE_matrix=MAE_matrix[1:10,1:10]
optimal_MAE  = which(MAE_matrix == min(MAE_matrix), arr.ind = T)
MAE_INDEX  = which(names(mae) == paste(rownames(MAE_matrix)[optimal_MAE[1]],colnames(MAE_matrix)[optimal_MAE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using MAE =",colnames(MAE_matrix)[optimal_MAE[2]])
paste("Optimal lambda forgetting factor value using MAE =",rownames(MAE_matrix)[optimal_MAE[1]])

result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,MAE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,MAE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,MAE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,MAE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,MAE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,MAE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")
result_BRENT_MAE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_BRENT_MAE, file="result_Brent_MAE.csv")

## Step 5-1-2:  DMA process��RMSE�� ##
RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])


result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")

result_BRENT_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_BRENT_RMSE, file="result_Brent_RMSE.csv")

##############################################################################
################################data for frequency############################
##############################################################################

library(zoo)
number=ceiling(log2(length(Data)))-1
library("Rlibeemd")
Data <- read.xlsx("data2.xlsx",sheetIndex=1)
time1=as.Date(Data[,1])
Data=Data[,-1]
data.z=zoo(Data[,1],as.Date(time1))
INE=data.z
IMFS <- ceemdan(INE, num_siftings = 9,threads = 1)
IMF1=zoo(IMFS[,1],as.Date(time1))
IMF2=zoo(IMFS[,2],as.Date(time1))
IMF3=zoo(IMFS[,3],as.Date(time1))
IMF4=zoo(IMFS[,4],as.Date(time1))
IMF5=zoo(IMFS[,5],as.Date(time1))
IMF6=zoo(IMFS[,6],as.Date(time1))
IMF7=zoo(IMFS[,7],as.Date(time1))
IMF8=zoo(IMFS[,8],as.Date(time1))
Residul9=zoo(IMFS[,9],as.Date(time1))
ibmr=merge.zoo(IMF1,IMF2,IMF3,IMF4,IMF5,IMF6,IMF7,IMF8,Residul9)


write.xlsx(ibmr, file="frequency components.xlsx")
ibmr=as.data.frame(ibmr)
ibmrtb=t(ibmr)
round(ibmrtb, 1)
ibmrt = scale(ibmrtb)
km.res = kmeans(ibmrt, 3)
fviz_cluster(km.res, ibmrt)
sil = silhouette(km.res$cluster, dist(ibmrt))
rownames(sil) = rownames(ibmrt)
head(sil[, 1:3])
fviz_silhouette(sil)


fclasses <- hclust(dist(ibmrt),"ward.D")
plot(fclasses,hang=-1)
re <- rect.hclust(fclasses, k = 3)


ibmr.la8 <- modwt(INE, "la8",n.levels = 8)
IMF1=zoo(ibmr.la8[["d1"]],as.Date(time1))
IMF2=zoo(ibmr.la8[["d2"]],as.Date(time1))
IMF3=zoo(ibmr.la8[["d3"]],as.Date(time1))
IMF4=zoo(ibmr.la8[["d4"]],as.Date(time1))
IMF5=zoo(ibmr.la8[["d5"]],as.Date(time1))
IMF6=zoo(ibmr.la8[["d6"]],as.Date(time1))
IMF7=zoo(ibmr.la8[["d7"]],as.Date(time1))
IMF8=zoo(ibmr.la8[["d8"]],as.Date(time1))
Residul9=zoo(ibmr.la8[["s8"]],as.Date(time1))

ibmr=merge.zoo(IMF1,IMF2,IMF3,IMF4,IMF5,IMF6,IMF7,IMF8,Residul9)
write.xlsx(ibmr, file="frequency components wavelet.xlsx")

library(factoextra)
library(cluster)
ibmr=as.data.frame(ibmr)
ibmrtb=t(ibmr)
round(ibmrtb, 1)
ibmrt = scale(ibmrtb)
km.res = kmeans(ibmrt, 3)
fviz_cluster(km.res, ibmrt)
sil = silhouette(km.res$cluster, dist(ibmrt))
rownames(sil) = rownames(ibmrt)
head(sil[, 1:3])
fviz_silhouette(sil)


fclasses <- hclust(dist(ibmrt),"centroid")
plot(fclasses,hang=-1)
re <- rect.hclust(fclasses, k = 3)




### Step 7:   frequency domain research #####

setwd("d:/����/9 IN.E and China fianncial factor/��д")
x<-as.matrix(cbind(
  IR<-Data$IR,
  ER<-Data$ER,
  SHCI<-Data$SHCI,
  TR<-Data$TR,
  EI<-Data$EI,
  CP<-Data$CP
))
data <- read.xlsx("frequency components wavelet.xlsx",sheetIndex=1)
y<-as.matrix(data[,2])
y<-as.matrix(data[,3])
y<-as.matrix(data[,4])


LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))


residuals              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                  = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    print(paste(LAMBDA,ALPHA,sep="_"))
    out.temp <- dma(x[,1:6],y,expand.grid(rep(list(0:1), ncol(x[,1:6]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=0)
    
    rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
    mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
    
    col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
    
    temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:6]))))
    
    prob_IR[,col_index]                 = temp_probs[,1]
    prob_ER[,col_index]                 = temp_probs[,2]
    prob_SHCI[,col_index]               = temp_probs[,3]
    prob_TR[,col_index]                 = temp_probs[,4]
    prob_EI[,col_index]                 = temp_probs[,5]
    prob_CP[,col_index]                 = temp_probs[,6]

    
    residuals[,col_index]                  = out.temp$residuals
    alpha[,col_index]                      = out.temp$thetahat.ma[,1]
    theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
    theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
    theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,4]
    theta_TR[,col_index]                   = out.temp$thetahat.ma[,5]
    theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
    theta_CP[,col_index]                   = out.temp$thetahat.ma[,7]

  }
}

MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))

rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
    RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
  }
}


RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])

result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]

par(mfrow=c(3,2))
plot(result_IR[40:603],type='l',col="navy")
plot(result_ER[40:603],type='l',col="navy")
plot(result_TR[40:603],type='l',col="navy")
plot(result_SHCI[40:603],type='l',col="navy")
plot(result_EI[40:603],type='l',col="navy")
plot(result_CP[40:603],type='l',col="navy")

result_F1_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_F1_RMSE, file="result_F1_RMSE.csv")
result_F2_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_F2_RMSE, file="result_F2_RMSE.csv")
result_F3_RMSE<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_F3_RMSE, file="result_F3_RMSE.csv")


total=out.temp$pmp
write.csv(total,file = "total-frequncy1.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "frequncy1.csv")

total=out.temp$pmp
write.csv(total,file = "total-frequncy2.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "frequncy2.csv")

total=out.temp$pmp
write.csv(total,file = "total-frequncy3.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "frequncy3.csv")


####  Step 6:  Estimation for INE other horizons #####
## Step 6-1:  DMA process for positive and negative##
Data <- read.xlsx("data2forpandn.xlsx",sheetIndex=1)
y<-as.matrix(Data[,2])
x<-as.matrix(cbind(
  IR<-Data$IR,
  ER<-Data$ER,
  TR<-Data$TR,
  SHCI<-Data$SHCI,
  EI<-Data$EI,
  CP<-Data$CP
))

LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))



residuals               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                   = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))


burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    print(paste(LAMBDA,ALPHA,sep="_"))
    out.temp <- dma(x[,1:6],y,expand.grid(rep(list(0:1), ncol(x[,1:6]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=40)
    
    rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
    mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
    
    col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
    
    temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:6]))))
    
    prob_IR[,col_index]                 = temp_probs[,1]
    prob_ER[,col_index]                 = temp_probs[,2]
    prob_TR[,col_index]                 = temp_probs[,3]
    prob_SHCI[,col_index]               = temp_probs[,4]
    prob_EI[,col_index]                 = temp_probs[,5]
    prob_CP[,col_index]                 = temp_probs[,6]
    
    
    
    residuals[,col_index]                  = out.temp$residuals
    alpha[,col_index]                      = out.temp$thetahat.ma[,1]
    theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
    theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
    theta_TR[,col_index]                   = out.temp$thetahat.ma[,4]
    theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,5]
    theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
    theta_CP[,col_index]                   = out.temp$thetahat.ma[,7]
    
  }
}

MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))

rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
    RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
  }
}

total=out.temp$pmp
write.csv(total,file = "total_positive.csv")
knowmodels=expand.grid(rep(list(0:1), ncol(x[,1:6])))
write.csv(knowmodels,file = "knowmodels_positive.csv")

RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])


result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]


par(mfrow=c(3,2))
plot(result_IR[41:603],type='l',col="navy")
plot(result_ER[41:603],type='l',col="navy")
plot(result_TR[41:603],type='l',col="navy")
plot(result_SHCI[41:603],type='l',col="navy")
plot(result_EI[41:603],type='l',col="navy")
plot(result_CP[41:603],type='l',col="navy")


result_INE_RMSE_h4<-as.matrix(cbind(result_IR,result_ER,result_TR,result_SHCI,result_EI,result_CP))
write.csv(result_INE_RMSE_h4, file="result_INE_negative.csv")



































####  Step 6:  Estimation for WTI and Brent #####
## Step 6-1:  DMA process for WTI##

Data <- read.xlsx("data1.xlsx",sheetIndex=4)
y<-as.matrix(Data[,2])
x<-as.matrix(cbind(
  IR<-Data$ir,
  ER<-Data$er,
  SHCI<-Data$SHCI,
  TR<-Data$TR,
  EI<-Data$EI,
  CP<-Data$CP,
  EPU<-Data$EPU
))



LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EPU                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))


residuals              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                  = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EPU              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))


burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    print(paste(LAMBDA,ALPHA,sep="_"))
    out.temp <- dma(x[,1:7],y,expand.grid(rep(list(0:1), ncol(x[,1:7]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=0)
    
    rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
    mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
    
    col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
    
    temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:7]))))
    
    prob_IR[,col_index]                 = temp_probs[,1]
    prob_ER[,col_index]                 = temp_probs[,2]
    prob_SHCI[,col_index]               = temp_probs[,3]
    prob_TR[,col_index]                 = temp_probs[,4]
    prob_EI[,col_index]                 = temp_probs[,5]
    prob_CP[,col_index]                 = temp_probs[,6]
    prob_EPU[,col_index]                 = temp_probs[,7]
    
    
    residuals[,col_index]                  = out.temp$residuals
    alpha[,col_index]                      = out.temp$thetahat.ma[,1]
    theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
    theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
    theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,4]
    theta_TR[,col_index]                   = out.temp$thetahat.ma[,5]
    theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
    theta_CP[,col_index]                   = out.temp$thetahat.ma[,7]
    theta_EPU[,col_index]                   = out.temp$thetahat.ma[,7]
    
  }
}

MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))

rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
    RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
  }
}


## Step 6-1-1:  DMA process��MAE�� ##
MAE_matrix=MAE_matrix[1:10,1:10]
optimal_MAE  = which(MAE_matrix == min(MAE_matrix), arr.ind = T)
MAE_INDEX  = which(names(mae) == paste(rownames(MAE_matrix)[optimal_MAE[1]],colnames(MAE_matrix)[optimal_MAE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using MAE =",colnames(MAE_matrix)[optimal_MAE[2]])
paste("Optimal lambda forgetting factor value using MAE =",rownames(MAE_matrix)[optimal_MAE[1]])

result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,MAE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,MAE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,MAE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,MAE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,MAE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,MAE_INDEX]
result_EPU<-eval(parse(text= paste("prob","EPU",sep="_") ))[,MAE_INDEX]

par(mfrow=c(4,2))
plot(result_IR[41:536],type='l',col="navy")
plot(result_ER[41:536],type='l',col="navy")
plot(result_SHCI[41:536],type='l',col="navy")
plot(result_TR[41:536],type='l',col="navy")
plot(result_EI[41:536],type='l',col="navy")
plot(result_CP[41:536],type='l',col="navy")
plot(result_EPU[41:536],type='l',col="navy")

## Step 6-1-2:  DMA process��RMSE�� ##
RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])


result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]
result_EPU<-eval(parse(text= paste("prob","EPU",sep="_") ))[,RMSE_INDEX]

par(mfrow=c(4,2))
plot(result_IR[41:536],type='l',col="navy")
plot(result_ER[41:536],type='l',col="navy")
plot(result_SHCI[41:536],type='l',col="navy")
plot(result_TR[41:536],type='l',col="navy")
plot(result_EI[41:536],type='l',col="navy")
plot(result_CP[41:536],type='l',col="navy")
plot(result_EPU[41:536],type='l',col="navy")


## Step 6-1:  DMA process for Brent##

Data <- read.xlsx("data1.xlsx",sheetIndex=5)
y<-as.matrix(Data[,2])
x<-as.matrix(cbind(
  IR<-Data$ir,
  ER<-Data$er,
  SHCI<-Data$SHCI,
  TR<-Data$TR,
  EI<-Data$EI,
  CP<-Data$CP,
  EPU<-Data$EPU
))



LAMBDA_range = seq(.90,1,.01) 
ALPHA_range  = seq(.90,1,.01) 


prob_IR               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_SHCI               = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_TR                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EI                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_CP                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
prob_EPU                 = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))


residuals              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
alpha                  = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_IR                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_ER                = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_SHCI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_TR              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EI              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_CP              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))
theta_EPU              = matrix(NA,length(y),(length(LAMBDA_range)*length(ALPHA_range)))


burn    =40  ###set burn period for reducing estimation error###
rmse    = vector(mode="list")
mae     = vector(mode="list")


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    print(paste(LAMBDA,ALPHA,sep="_"))
    out.temp <- dma(x[,1:7],y,expand.grid(rep(list(0:1), ncol(x[,1:7]))),delay=0,lambda=LAMBDA,gamma=ALPHA,initialperiod=0)
    
    rmse[[paste(LAMBDA,ALPHA,sep="_")]]    = sqrt(mean((y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)])^2))
    mae[[paste(LAMBDA,ALPHA,sep="_")]]     = mean(abs(y[-c(1:burn)]-out.temp$yhat.ma[-c(1:burn)]))
    
    col_index = which(names(rmse)==paste(LAMBDA,ALPHA,sep="_"))
    
    temp_probs = as.matrix(out.temp$pmp)%*%as.matrix(expand.grid(rep(list(0:1), ncol(x[,1:7]))))
    
    prob_IR[,col_index]                 = temp_probs[,1]
    prob_ER[,col_index]                 = temp_probs[,2]
    prob_SHCI[,col_index]               = temp_probs[,3]
    prob_TR[,col_index]                 = temp_probs[,4]
    prob_EI[,col_index]                 = temp_probs[,5]
    prob_CP[,col_index]                 = temp_probs[,6]
    prob_EPU[,col_index]                 = temp_probs[,7]
    
    
    residuals[,col_index]                  = out.temp$residuals
    alpha[,col_index]                      = out.temp$thetahat.ma[,1]
    theta_IR[,col_index]                   = out.temp$thetahat.ma[,2]
    theta_ER[,col_index]                   = out.temp$thetahat.ma[,3]
    theta_SHCI[,col_index]                 = out.temp$thetahat.ma[,4]
    theta_TR[,col_index]                   = out.temp$thetahat.ma[,5]
    theta_EI[,col_index]                   = out.temp$thetahat.ma[,6]
    theta_CP[,col_index]                   = out.temp$thetahat.ma[,7]
    theta_EPU[,col_index]                   = out.temp$thetahat.ma[,7]
    
  }
}

MAE_matrix  = matrix(NA,length(LAMBDA_range),length(ALPHA_range))
RMSE_matrix = matrix(NA,length(LAMBDA_range),length(ALPHA_range))

rownames(MAE_matrix) = rownames(RMSE_matrix) = paste(LAMBDA_range)
colnames(MAE_matrix) = colnames(RMSE_matrix) = paste(LAMBDA_range)


for (LAMBDA in LAMBDA_range)
{
  for (ALPHA in ALPHA_range)
  {
    MAE_matrix[paste(LAMBDA),paste(ALPHA)]  = mae[[paste(LAMBDA,ALPHA,sep="_")]] 
    RMSE_matrix[paste(LAMBDA),paste(ALPHA)] = rmse[[paste(LAMBDA,ALPHA,sep="_")]] 
  }
}


## Step 6-2-1:  DMA process��MAE�� ##
MAE_matrix=MAE_matrix[1:10,1:10]
optimal_MAE  = which(MAE_matrix == min(MAE_matrix), arr.ind = T)
MAE_INDEX  = which(names(mae) == paste(rownames(MAE_matrix)[optimal_MAE[1]],colnames(MAE_matrix)[optimal_MAE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using MAE =",colnames(MAE_matrix)[optimal_MAE[2]])
paste("Optimal lambda forgetting factor value using MAE =",rownames(MAE_matrix)[optimal_MAE[1]])

result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,MAE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,MAE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,MAE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,MAE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,MAE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,MAE_INDEX]
result_EPU<-eval(parse(text= paste("prob","EPU",sep="_") ))[,MAE_INDEX]

par(mfrow=c(4,2))
plot(result_IR[41:536],type='l',col="navy")
plot(result_ER[41:536],type='l',col="navy")
plot(result_SHCI[41:536],type='l',col="navy")
plot(result_TR[41:536],type='l',col="navy")
plot(result_EI[41:536],type='l',col="navy")
plot(result_CP[41:536],type='l',col="navy")
plot(result_EPU[41:536],type='l',col="navy")

## Step 6-2-2:  DMA process��RMSE�� ##
RMSE_matrix=RMSE_matrix[1:10,1:10]
optimal_RMSE = which(RMSE_matrix == min(RMSE_matrix), arr.ind = T)
RMSE_INDEX = which(names(rmse) == paste(rownames(RMSE_matrix)[optimal_RMSE[1]],colnames(RMSE_matrix)[optimal_RMSE[2]],sep="_"))
paste("Optimal alpha forgetting factor value using RMSE =",colnames(RMSE_matrix)[optimal_RMSE[2]])
paste("Optimal lambda forgetting factor value using RMSE =",rownames(RMSE_matrix)[optimal_RMSE[1]])


result_IR<-eval(parse(text= paste("prob","IR",sep="_") ))[,RMSE_INDEX]
result_ER<-eval(parse(text= paste("prob","ER",sep="_") ))[,RMSE_INDEX]
result_SHCI<-eval(parse(text= paste("prob","SHCI",sep="_") ))[,RMSE_INDEX]
result_TR<-eval(parse(text= paste("prob","TR",sep="_") ))[,RMSE_INDEX]
result_EI<-eval(parse(text= paste("prob","EI",sep="_") ))[,RMSE_INDEX]
result_CP<-eval(parse(text= paste("prob","CP",sep="_") ))[,RMSE_INDEX]
result_EPU<-eval(parse(text= paste("prob","EPU",sep="_") ))[,RMSE_INDEX]

par(mfrow=c(4,2))
plot(result_IR[41:536],type='l',col="navy")
plot(result_ER[41:536],type='l',col="navy")
plot(result_SHCI[41:536],type='l',col="navy")
plot(result_TR[41:536],type='l',col="navy")
plot(result_EI[41:536],type='l',col="navy")
plot(result_CP[41:536],type='l',col="navy")
plot(result_EPU[41:536],type='l',col="navy")






################losse somoth#####
setwd("d:/����/9 INE and China fianncial factor/��д")
Data <- read.xlsx("data for loess.xlsx",sheetIndex=1)
loessMod50 <- loess(result_ER ~ index, data=Data, span=0.50) # 50% smoothing span
smoothed1 <- predict(loessMod50) 
plot(Data$result_ER, x=Data$Time, type="l", main="Loess Smoothing and Prediction", xlab="Date", ylab="DMA postiror probablility")
lines(smoothed1, x=Data$Time, col="blue")

loessMod50 <- loess(result_IR ~ index, data=Data, span=0.50) # 50% smoothing span
smoothed2 <- predict(loessMod50) 
plot(Data$result_IR, x=Data$Time, type="l", main="Loess Smoothing and Prediction", xlab="Date", ylab="DMA postiror probablility")
lines(smoothed2, x=Data$Time, col="blue")

loessMod50 <- loess(result_TR ~ index, data=Data, span=0.50) # 50% smoothing span
smoothed3 <- predict(loessMod50) 
plot(Data$result_TR, x=Data$Time, type="l", main="Loess Smoothing and Prediction", xlab="Date", ylab="DMA postiror probablility")
lines(smoothed3, x=Data$Time, col="blue")

loessMod50 <- loess(result_SHCI ~ index, data=Data, span=0.50) # 50% smoothing span
smoothed4 <- predict(loessMod50) 
plot(Data$result_SHCI, x=Data$Time, type="l", main="Loess Smoothing and Prediction", xlab="Date", ylab="DMA postiror probablility")
lines(smoothed4, x=Data$Time, col="blue")

loessMod50 <- loess(result_EI ~ index, data=Data, span=0.50) # 50% smoothing span
smoothed5 <- predict(loessMod50) 
plot(Data$result_EI, x=Data$Time, type="l", main="Loess Smoothing and Prediction", xlab="Date", ylab="DMA postiror probablility")
lines(smoothed5, x=Data$Time, col="blue")

loessMod50 <- loess(result_CP ~ index, data=Data, span=0.50) # 50% smoothing span
smoothed6 <- predict(loessMod50) 
plot(Data$result_CP, x=Data$Time, type="l", main="Loess Smoothing and Prediction", xlab="Date", ylab="DMA postiror probablility")
lines(smoothed6, x=Data$Time, col="blue")





