
Sys.setlocale("LC_TIME", "English")
#####descriptive analysis#####
setwd("D:/����/10 Covid-19/dataset/")
library(xlsx)
library(zoo)
library(vars)
library(PerformanceAnalytics)
library(tseries)
#descriptive fro two sub###
Data<- read.xlsx("D:/����/10 Covid-19/dataset/data2.xlsx", sheetIndex = 1)
data.z = zoo(Data, as.Date(Data[,1], origin="1899-12-30"))
data.z=data.z[,-1]
X=Data[,-1]
descriptives = matrix(NA,length(names(Data)[-1]),8)
rownames(descriptives)=names(Data)[-1]
colnames(descriptives)=c("Mean", "Max.", "Min", "St.Dev.", "Skewness", "Kurtosis", "J.B.", "ADF")
signif.num <- function(x) 
{
  symnum(x, corr = FALSE, na = FALSE, legend = FALSE,
         cutpoints = c(0, 0.01, 0.05, 0.1, 1), 
         symbols = c("****", "***", "**", "*"))
}

Basic_descriptives = function(z)
{
  c(round(c( mean(z),max(z),min(z),sd(z),skewness(z),kurtosis(z)),3),
    suppressWarnings(paste(round(jarque.bera.test(z)$statistic,3),signif.num(jarque.bera.test(z)$p.value),sep="")),
    suppressWarnings(paste(round(adf.test(z)$statistic,3),signif.num(adf.test(z)$p.value),sep=""))
  )
}

for (i in 1:length(X[1,]) ){descriptives[i,] = Basic_descriptives(X[,i])}
descriptives






Data<- read.xlsx("D:/����/10 Covid-19/dataset/data1.xlsx", sheetIndex = 1)
data.z = zoo(Data, as.Date(Data[,1], origin="1899-12-30"))
data.z=data.z[,-1]

Data<- read.xlsx("D:/����/10 Covid-19/dataset/data1.xlsx", sheetIndex = 2)
data.z = zoo(Data, as.Date(Data[,1], origin="1899-12-30"))
data.z=data.z[,-1]
descriptive_in_manuscript=table.Stats(data.z)
write.csv(descriptive_in_manuscript,file="descriptive_in_manuscript.csv")
jbt=jarque.bera.test(data.z[,1])$statistic
jbt1=jbt[[1]]
jbt=jarque.bera.test(data.z[,3])$statistic
jbt2=jbt[[1]]
jbt=jarque.bera.test(data.z[,4])$statistic
jbt3=jbt[[1]]
jbt=jarque.bera.test(data.z[,5])$statistic
jbt4=jbt[[1]]
jbt=jarque.bera.test(data.z[,6])$statistic
jbt5=jbt[[1]]
jbt=jarque.bera.test(data.z[,7])$statistic
jbt6=jbt[[1]]
jbt=jarque.bera.test(data.z[,8])$statistic
jbt7=jbt[[1]]
jarque.bera.test = cbind(jbt1, jbt2, jbt3, jbt4,jbt5,jbt6,jbt7)
jarque.bera.test
jbp=jarque.bera.test(data.z[,1])$p.value
jbp1=jbp[[1]]
jbp=jarque.bera.test(data.z[,3])$p.value
jbp2=jbp[[1]]
jbp=jarque.bera.test(data.z[,4])$p.value
jbp3=jbp[[1]]
jbp=jarque.bera.test(data.z[,5])$p.value
jbp4=jbp[[1]]
jbp=jarque.bera.test(data.z[,6])$p.value
jbp5=jbp[[1]]
jbp=jarque.bera.test(data.z[,7])$p.value
jbp6=jbp[[1]]
jbp=jarque.bera.test(data.z[,8])$p.value
jbp7=jbp[[1]]
jarque.bera.p.value= cbind(jbp1, jbp2, jbp3, jbp4,jbp5,jbp6,jbp7)
jarque.bera.p.value
adf.test(data.z$WTI)
adf.test(data.z$Gasoline)
adf.test(data.z$HeatingOil)
adf.test(data.z$Diesel)
adf.test(data.z$Kerosene)
adf.test(data.z$Propane)
adf.test(data.z$Naturegas)
pp.test(data.z$WTI)
pp.test(data.z$Gasoline)
pp.test(data.z$HeatingOil)
pp.test(data.z$Diesel)
pp.test(data.z$Kerosene)
pp.test(data.z$Propane)
pp.test(data.z$Naturegas)
#############################
Data1<- read.xlsx("E:/�о��������ļ�/10 Covid-19/dataset/data.xlsx", sheetIndex = 6)
data.z1 = zoo(Data1, as.Date(Data1[,1], origin="1899-12-30"))
data.z1=data.z1[,-1]
descriptive_in_appendix=table.Stats(data.z1)
write.csv(descriptive_in_appendix,file="descriptive_in_appendix.csv")
jbt=jarque.bera.test(data.z1[,1])$statistic
jbt1=jbt[[1]]
jbt=jarque.bera.test(data.z1[,2])$statistic
jbt2=jbt[[1]]
jbt=jarque.bera.test(data.z1[,3])$statistic
jbt3=jbt[[1]]
jbt=jarque.bera.test(data.z1[,4])$statistic
jbt4=jbt[[1]]
jbt=jarque.bera.test(data.z1[,5])$statistic
jbt5=jbt[[1]]
jarque.bera.test = cbind(jbt1, jbt2, jbt3, jbt4,jbt5)
jarque.bera.test
jbp=jarque.bera.test(data.z1[,1])$p.value
jbp1=jbp[[1]]
jbp=jarque.bera.test(data.z1[,2])$p.value
jbp2=jbp[[1]]
jbp=jarque.bera.test(data.z1[,3])$p.value
jbp3=jbp[[1]]
jbp=jarque.bera.test(data.z1[,4])$p.value
jbp4=jbp[[1]]
jbp=jarque.bera.test(data.z1[,5])$p.value
jbp5=jbp[[1]]
jarque.bera.p.value= cbind(jbp1, jbp2, jbp3, jbp4,jbp5)
jarque.bera.p.value
adf.test(data.z1$total)
adf.test(data.z1$rise)
adf.test(data.z1$EPU)
adf.test(data.z1$VIX)
adf.test(data.z1$OVX)
pp.test(data.z1$total)
pp.test(data.z1$rise)
pp.test(data.z1$EPU)
pp.test(data.z1$VIX)
pp.test(data.z1$OVX)
#############################
timea<-as.Date(Data[,1],origin = "1899-12-30")
rownames(Data)<-timea
Data=Data[,-1]
#######density plot#########
panel.density <- function(x, ...)
{usr <- par("usr"); on.exit(par(usr))
par(usr = c(usr[1:2], 0, max(density(x)$y)*1.1) )
lines(density(x), col="navy")
rug(x)}
#####correlation plot#######
panel.cor <- function(x, y, digits=2, cex.cor)
{usr <- par("usr"); on.exit(par(usr))
par(usr = c(0, 1, 0, 1))
r <- cor(x, y, use="complete.obs"); r1 <- abs(r)
txt <- format(c(r, 0.123456789), digits=digits)[1]
if(missing(cex.cor)) cex <- 0.8/strwidth(txt)
text(0.5, 0.5, txt, cex = 2)}
#######hist plot###########
panel.hist<-function(x,...)
{usr <- par("usr"); on.exit(par(usr))
par(usr = c(usr[1:2], 0, 1.5))
h<-hist(x, plot=FALSE)
breaks<-h$breaks;nB<-length(breaks)
y<-h$counts;y<-y/max(y)
rect(breaks[-nB],0,breaks[-1],y,col="navy",...)
}
#draw a picuture#
pairs(Data,diag.panel=panel.hist,upper.panel=panel.smooth,lower.panel=panel.cor,cex.labels = 1, font.labels = 2)
####################

### ANTONAKAKIS, N., AND GABAUER, D. (2017)
### REFINED MEASURES OF DYNAMIC CONNECTEDNESS BASED ON TIME-VARYING PARAMETERS VECTOR AUTREGRESSIONS
### by David Gabauer (https://sites.google.com/view/davidgabauer/contact-details)

UninformativePrior = function(gamma, r, nlag, m){
  A_prior = cbind(0*diag(r), matrix(0, ncol=(nlag-1)*r, nrow=r))
  aprior = c(A_prior)
  V_i = matrix(0, nrow=(m/r), ncol=r)
  for (i in 1:r){
    for (j in 1:(m/r)) {
      V_i[j,i] = gamma/(ceiling(j/r)^2)
    }
  }
  # Now V (MINNESOTA VARIANCE) is a diagonal matrix with diagonal elements the V_i'  
  V_i_T = t(V_i)
  Vprior = diag(c(V_i_T))
  diag(Vprior)
  return = list(aprior=aprior, Vprior=Vprior)
}

TVPVAR = function(Y, l, nlag, beta_0.mean, beta_0.var, Q_0){
  create_RHS_NI = function(templag, r, nlag, t){
    K = nlag*(r^2)
    x_t = matrix(0, (t-nlag)*r, K)
    for (i in 1:(t-nlag)){
      ztemp=NULL
      for (j in 1:nlag){
        xtemp = templag[i,((j-1)*r+1):(j*r)]
        xtemp = t(kronecker(diag(r),xtemp))
        ztemp = cbind(ztemp, xtemp)
      }
      x_t[((i-1)*r+1):(i*r),] = ztemp
    }
    return=list(x_t=x_t, K=K)
  }
  Y = scale(Y,T,F)
  y_true = 0
  FPC = Y
  YX = cbind(Y,Y)
  nfac = 0
  p = n = ncol(Y)
  r = nfac + p
  m = nlag*(r^2)
  k = nlag*r
  t = nrow(FPC)
  q = n + p
  Q_0 = Q_0
  
  # Initialize matrices
  beta_0_prmean = beta_0.mean
  beta_0_prvar = beta_0.var
  
  beta_pred = matrix(0,m,t)
  beta_update = matrix(0,m,t)
  
  Rb_t = array(0,c(m,m,t))
  Sb_t = array(0,c(m,m,t))
  
  beta_t = array(0, c(k,k,t))
  Q_t = array(0, c(r,r,t))
  
  # Decay and forgetting factors
  l_2 = l[1]
  l_4 = l[2]
  
  # Define lags of the factors to be used in the state (VAR) equation         
  yy = FPC[(nlag+1):t,]      
  xx = embed(FPC,nlag+1)[,-c(1:ncol(FPC))]
  templag = embed(FPC,nlag+1)[,-c(1:ncol(FPC))]
  RHS1 = create_RHS_NI(templag,r,nlag,t);  
  Flagtemp = RHS1$x_t
  m = RHS1$K
  Flag = rbind(matrix(0, k,m), Flagtemp)
  
  ###-----| 1. KALMAN FILTER
  for (irep in 1:t){
    #-----| Update the state covariances
    # 1. Get the variance of the factor
    
    # Update Q[t]
    if (irep==1){
      Q_t[,,irep] = Q_0
    } else if (irep > 1) {
      if (irep <= (nlag+1)) { 
        Gf_t = 0.1*(t(matrix(FPC[irep,],nrow=1))%*%(FPC[irep,]))
      } else {
        Gf_t = t(yy[(irep-nlag),]-xx[(irep-nlag),]%*%t(B[1:r,1:k])) %*% (yy[(irep-nlag),]-xx[(irep-nlag),]%*%t(B[1:r,1:k]))
      }
      Q_t[,,irep] = l_2*Q_t[,,(irep-1)] + (1-l_2)*Gf_t[1:r,1:r]
    }
    # -for beta
    if (irep <= (nlag+1)) {
      beta_pred[,irep] = beta_0_prmean
      beta_update[,irep] = beta_pred[,irep]
      Rb_t[,,irep] = beta_0_prvar
    } else if (irep > (nlag+1)) {
      beta_pred[,irep] = beta_update[,(irep-1)]
      Rb_t[,,irep] = (1/l_4)*Sb_t[,,(irep-1)]
    }
    
    # -for beta
    if (irep >= (nlag+1)) {
      # 2/ Update VAR coefficients conditional on Principal Componets estimates
      Rx = Rb_t[,,irep]%*%t(Flag[((irep-1)*r+1):(irep*r),])
      KV_b = Q_t[,,irep] + Flag[((irep-1)*r+1):(irep*r),]%*%Rx
      KG = Rx%*%MASS::ginv(KV_b)
      beta_update[,irep] = matrix(beta_pred[,irep], ncol=1) + (KG%*%(t(matrix(FPC[irep,], nrow=1))-Flag[((irep-1)*r+1):(irep*r),]%*%matrix(beta_pred[,irep], ncol=1)) )
      Sb_t[,,irep] = Rb_t[,,irep] - KG%*%(Flag[((irep-1)*r+1):(irep*r),]%*%Rb_t[,,irep])
    }
    
    # Assign coefficients
    bb = matrix(beta_update[,irep], ncol=1)
    splace = 0
    biga = matrix(0, r,r*nlag)
    for (ii in 1:nlag) {                                          
      for (iii in 1:r) {           
        biga[iii,((ii-1)*r+1):(ii*r)] = t(bb[(splace+1):((splace+r)),1])
        splace = splace + r
      }
    }
    
    B = rbind(biga, cbind(diag(r*(nlag-1)), matrix(0, nrow=r*(nlag-1), ncol=r)))
    
    if ((max(abs(eigen(B)$values))<=1)||(irep==1)){
      beta_t[,,irep] = B
    } else {
      beta_t[,,irep] = beta_t[,,(irep-1)]
      beta_update[,irep] = 0.99*beta_update[,(irep-1)]
    }
  }
  
  return = list(beta_t=beta_t[1:ncol(Y),,], Q_t=Q_t)
}
tvp.Phi = function (x, nstep = 10, ...) {
  nstep = abs(as.integer(nstep))
  K=nrow(x)
  p=floor(ncol(x)/K)
  A = array(0, c(K,K,nstep))
  for (i in 1:p){
    A[,,i]=x[,((i-1)*K+1):(i*K)]
  }
  
  Phi = array(0, dim = c(K, K, nstep + 1))
  Phi[, , 1] = diag(K)
  Phi[, , 2] = Phi[, , 1] %*% A[, , 1]
  if (nstep > 1) {
    for (i in 3:(nstep + 1)) {
      tmp1 = Phi[, , 1] %*% A[, , i - 1]
      tmp2 = matrix(0, nrow = K, ncol = K)
      idx = (i - 2):1
      for (j in 1:(i - 2)) {
        tmp2 = tmp2 + Phi[, , j + 1] %*% A[, , idx[j]]
      }
      Phi[, , i] = tmp1 + tmp2
    }
  }
  return(Phi)
}
tvp.gfevd = function(model, Sigma, n.ahead=10,normalize=TRUE,standardize=TRUE) {
  A = tvp.Phi(model, (n.ahead-1))
  Sigma = Sigma
  gi = array(0, dim(A))
  sigmas = sqrt(diag(Sigma))
  for (j in 1:dim(A)[3]) {
    gi[,,j] = t(A[,,j]%*%Sigma%*%MASS::ginv(diag(sqrt(diag(Sigma)))))
  }
  if (standardize==TRUE){
    girf=array(NA, c(dim(gi)[1],dim(gi)[2], (dim(gi)[3])))
    for (i in 1:dim(gi)[3]){
      girf[,,i]=((gi[,,i])%*%MASS::ginv(diag(diag(gi[,,1]))))
    }
    gi=girf
  }
  
  num = apply(gi^2,1:2,sum)
  den = c(apply(num,1,sum))
  fevd = t(num)/den
  nfevd = fevd
  if (normalize==TRUE) {
    fevd=(fevd/apply(fevd, 1, sum))
  } else {
    fevd=(fevd)
  }
  return = list(fevd=fevd, girf=gi, nfevd=nfevd)
}
DCA = function(CV){
  k = dim(CV)[1]
  SOFM = apply(CV,1:2,mean)*100 # spillover from others to one specific
  VSI = round(mean(100-diag(SOFM)),2)
  TO = colSums(SOFM-diag(diag(SOFM)))
  FROM = rowSums(SOFM-diag(diag(SOFM)))
  NET = TO-FROM
  NPSO = t(SOFM)-SOFM
  INC = rowSums(NPSO>0)
  ALL = rbind(format(round(cbind(SOFM,FROM),1),nsmall=1),c(format(round(TO,1),nsmall=1),format(round(sum(colSums(SOFM-diag(diag(SOFM)))),1),nsmall=1)),c(format(round(NET,1),nsmall=1),"TCI"),format(round(c(INC,VSI),1),nsmall=1))
  colnames(ALL) = c(rownames(CV),"FROM")
  rownames(ALL) = c(rownames(CV),"Contribution TO others","NET directional connectedness","NPDC transmitter")
  return = list(CT=SOFM,TCI=VSI,TO=TO,FROM=FROM,NET=NET,NPSO=NPSO,NPDC=INC,ALL=ALL)
}

#path = file.path(file.choose()) # select dy2012.csv
#DATA = read.csv(path)
### END
library(frequencyConnectedness)
Data=Data[,-1]
Y = Data[,]
date=timea
k = ncol(Y)
#####
lags=VARselect(Y, lag.max = 5, type = "both")  ## "const", "trend", "both", "none"
p=lags$selection[[1]]  ##
p
est <- VAR(Y, p = p, type = "const")
DYsp <- spilloverDY12(est, n.ahead = 100, no.corr = T)
overall(DYsp)
DYsp
pairwise(DYsp)
net(DYsp)
######basic
setwd("e:/�о��������ļ�/10 Covid-19/dataset/")
### TVP-VAR
nlag = p # VAR(5)
nfore = 15 # 10-step ahead forecast
m = nlag*(k^2)
t = nrow(Y)
l_1 = 0.99
l_2 = 0.99

prior = UninformativePrior(0.1, k, nlag, m)
beta_0.mean = prior$aprior
beta_0.var = prior$Vprior

tvpvar = TVPVAR(Y, l=c(l_1, l_2), nlag, beta_0.mean, beta_0.var, cov(Y))
B_t = tvpvar$beta_t
Q_t = tvpvar$Q_t

### DYNAMIC CONNECTEDNESS APPROACH
total = matrix(NA, ncol=1, nrow=t)
to = matrix(NA, ncol=k, nrow=t)
from = matrix(NA, ncol=k, nrow=t)
net = matrix(NA, ncol=k, nrow=t)
CV = npso = array(NA, c(k, k, t))
colnames(CV)=rownames(CV)=colnames(Y)
for (i in 1:t){
  CV[,,i] = tvp.gfevd(B_t[,,i], Q_t[,,i], n.ahead=nfore)$fevd
  vd = DCA(CV[,,i])
  to[i,] = vd$TO/k
  from[i,] = vd$FROM/k
  net[i,] = vd$NET/k
  npso[,,i] = vd$NPSO/k
  total[i,] = vd$TCI*k/(k-1)
}

nps = array(NA,c(t,k/2*(k-1)))
colnames(nps) = 1:ncol(nps)
jk = 1
for (i in 1:k) {
  for (j in 1:k) {
    if (j<=i) {
      next
    } else {
      nps[,jk] = npso[i,j,]
      colnames(nps)[jk] = paste0(colnames(Y)[i],"-",colnames(Y)[j])
      jk = jk + 1
    }
  }
}

PCI = array(NA,c(k,k,t))
for (i in 1:k) {
  for (j in 1:k) {
    x = matrix(2*(CV[i,j,]+CV[j,i,])/(CV[i,i,]+CV[i,j,]+CV[j,i,]+CV[j,j,]), ncol=1)
    colnames(x) = paste0(colnames(Y)[i],"-",colnames(Y)[j])
    PCI[i,j,] = x
  }
}
Sys.setlocale("LC_TIME", "English")
### DYNAMIC TOTAL CONNECTEDNESS
par(mfrow = c(1,1), oma = c(0,1,0,0) + 0.05, mar = c(1,1,1,1) + .05, mgp = c(0, 0.1, 0))
plot(date,total, type="l",xaxs="i",col="grey20", las=1, main="",ylab="",ylim=c(floor(min(total)),ceiling(max(total))),yaxs="i",xlab="",tck=0.01)
grid(NA,NULL,lty=1)
polygon(c(date,rev(date)),c(c(rep(0,nrow(total))),rev(total)),col="grey20", border="grey20")
box()

total_data=as.matrix(total)
write.csv(total_data,file="positive_total_data.csv")

### NET TOTAL DIRECTIONAL CONNECTEDNESS

par(mfrow = c(ceiling(k/2),2), oma = c(0,1,0,0) + 0.05, mar = c(1,1,1,1) + .05, mgp = c(0, 0.1, 0))
for (i in 1:k){
  plot(date,net[,i], xlab="",ylab="",type="l",xaxs="i",col="navy", las=1, main=paste("NET",colnames(Y)[i]),ylim=c(floor(min(net[,i])),ceiling(max(net[,i]))),tck=0.01,yaxs="i")
  grid(NA,NULL,lty=1)
  polygon(c(date,rev(date)),c(c(rep(0,nrow(net))),rev(net[,i])),col="navy", border="grey20")
  box()
}


net_data=as.matrix(net)
write.xlsx(net_data,file="positive_net_data.xlsx")


#####basic connnectedness for gephi#####
### NET PAIRWISE DIRECTIONAL CONNECTEDNESS
par(mfrow = c(ceiling(ncol(nps)/8),3), oma = c(0,1,0,0) + 0.05, mar = c(1,1,1,1) + .05, mgp = c(0, 0.1, 0))
for (i in 1:ncol(nps)) {
  plot(date,nps[,i], xlab="",ylab="",type="l",xaxs="i",col="navy", las=1, main=colnames(nps)[i],tck=0.02,yaxs="i",ylim=c(floor(min(nps)),ceiling(max(nps))))
  grid(NA,NULL,lty=1,col = "gray")
  polygon(c(date,rev(date)),c(c(rep(0,nrow(nps))),rev(nps[,i])),col="navy", border="navy")
  box()
}
write.csv(nps,file="net_data_for_circus_after_averaging.csv")
################################
######mediation################
###############################
library(xlsx)
Data1<- read.xlsx("E:/�о��������ļ�/10 Covid-19/dataset/data.xlsx", sheetIndex = 6)
#Results from OLS is good#
library(vars)
library(gma)
data1 = zoo(Data1, as.Date(Data1[,1]))
data1=data1[,-1]
Z=data1$total
M=data1$rise2
M=as.numeric(M)
R=data1$VIX
R=as.numeric(R)
data.S=merge.zoo(Z,M,R)
data.S=as.data.frame(data.S)
gma(data.S,model.type="single",delta=0.5)









